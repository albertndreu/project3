from scipy.spatial.distance import pdist, squareform
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage, average, cut_tree
import pandas as pd
import sys
from sklearn import metrics
from scipy.cluster.hierarchy import fcluster, cut_tree

df = pd.read_csv(sys.argv[1], sep=",")

if(sys.argv[1] == "vb.csv"):
    x = df.iloc[:,3:7]
    Y = df.iloc[:,7:8]
    Y = Y['position_number'].values.tolist()
    print(x)
    print(Y)
else:
    x = df.iloc[:,0:len(df.columns)-1]
    Y = df.iloc[:,len(df.columns)-1:len(df.columns)]
    Y = Y['1'].values.tolist()

distances = pdist(x.values, metric='euclidean')
print(distances)
dist_matrix = squareform(distances)


linkage_data_complete = linkage(dist_matrix, method='complete')
linkage_data_average = linkage(dist_matrix, method='average')

predicted_class_average = fcluster(linkage_data_average,6,criterion='maxclust')
predicted_class_complete = fcluster(linkage_data_complete,6,criterion='maxclust')

score_complete = metrics.rand_score(predicted_class_complete, Y)
score_average = metrics.rand_score(predicted_class_average, Y)

s1 = "Similarity score to ground truth average: " + str(score_average) + "\n"
s2 = "Similarity score to ground truth complete: "+  str(score_complete) + "\n"

f = open("resultsAHC.txt", "w")
f.write(s1)
f.write(s2)
f.close()



dendrogram(linkage_data_complete, truncate_mode='lastp', p=6)
print(cut_tree(linkage_data_complete,  n_clusters=7))

plt.title("Dendrogram complete (only classes)")

plt.figure()
plt.title("Dendrogram complete (whole)")
dendrogram(linkage_data_complete, color_threshold=140, truncate_mode='none', p=6)

plt.figure()
d1 = dendrogram(linkage_data_average, truncate_mode='lastp', p=6)
plt.title("Dendrogram average (only classes)")

plt.figure()
plt.title("Dendrogram average (whole)")
dendrogram(linkage_data_average, color_threshold=140, truncate_mode='none', p=6)


plt.show()

print(d1)





