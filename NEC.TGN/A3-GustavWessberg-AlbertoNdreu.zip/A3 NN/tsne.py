
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
import pandas as pd
import sys
df = pd.read_csv(sys.argv[1], sep=",")

if(sys.argv[1] == "vb.csv"):
    x = df.iloc[:,3:7]
    Y = df.iloc[:,7:8]
    Y = Y['position_number'].values.tolist()
    Y2C = []
    for i in Y:
        if i == 2 or i == 3 or i == 4:
            Y2C.append(1)
        else:
            Y2C.append(0)
    
    
    print(x)
    print(Y)
else:
   
    x = df.iloc[:,0:len(df.columns)-1]
    Y = df.iloc[:,len(df.columns)-1:len(df.columns)]
    Y = Y['1'].values.tolist()
    print(Y)



tsne = TSNE(n_components=2, verbose=1)
a = tsne.fit_transform(x)

j = pd.DataFrame(a)
j.columns = ["x","y"]


plt.scatter(j.x, j.y, s=20, c=Y2C, cmap='viridis')
plt.show()
