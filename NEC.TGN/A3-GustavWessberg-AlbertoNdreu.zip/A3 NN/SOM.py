import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from sklearn import datasets
import pandas as pd
import numpy as np
import sys
from sklearn.model_selection import train_test_split
from sklearn import metrics
from minisom import MiniSom
import matplotlib.pyplot as plt
from matplotlib.patches import RegularPolygon, Ellipse
from mpl_toolkits.axes_grid1 import make_axes_locatable
from matplotlib import cm, colorbar
from matplotlib.lines import Line2D

df = pd.read_csv(sys.argv[1], sep=",")

if(sys.argv[1] == "vb.csv"):
    x = df.iloc[:,3:7]
    Y = df.iloc[:,7:8]
    Y = Y['position_number'].values.tolist()
else:     

    x = df.iloc[:,0:len(df.columns)-1]
    Y = df.iloc[:,len(df.columns)-1:len(df.columns)]
    Y = Y['1'].values.tolist()

target = Y
t = target
data = x.to_numpy()
n_neurons = 20
m_neurons = 20
som = MiniSom(n_neurons, m_neurons, data.shape[1], sigma=3, learning_rate=.5, 
              neighborhood_function='gaussian', random_seed=0)


som.train(data, 100, verbose=True)  


f = plt.figure(figsize=(10, 10))
ax = f.add_subplot(111)

ax.set_aspect('equal')

plt.pcolor(som.distance_map().T, cmap='bone_r') 


markers = ['o', 's', 'D', 'p','P','4']
colors = ['C0', 'C1', 'C2','C3','C4','C5']
for cnt, xx in enumerate(data):
    
    w = som.winner(xx)
    print(cnt, xx, w, colors[target[cnt]-1])
    plt.plot(w[0]+.5, w[1]+.5, markers[target[cnt]-1], markerfacecolor='None',
             markeredgecolor=colors[target[cnt]-1], markersize=12, markeredgewidth=2)

xx, yy = som.get_euclidean_coordinates()
umatrix = som.distance_map()
print(umatrix)
weights = som.get_weights()

xrange = np.arange(weights.shape[0])
yrange = np.arange(weights.shape[1])
plt.xticks(xrange-.5, xrange)
plt.yticks(yrange * np.sqrt(3) / 2, yrange)

divider = make_axes_locatable(plt.gca())
ax_cb = divider.new_horizontal(size="5%", pad=0.05)    
cb1 = colorbar.ColorbarBase(ax_cb, cmap='bone_r', 
                            orientation='vertical', alpha=.4)
cb1.ax.get_yaxis().labelpad = 16
cb1.ax.set_ylabel('distance from neurons in the neighbourhood',
                  rotation=270, fontsize=16)
plt.gcf().add_axes(ax_cb)

legend_elements = [Line2D([0], [0], marker='o', color='C0', label='1',
                   markerfacecolor='w', markersize=14, linestyle='None', markeredgewidth=2),
                   Line2D([0], [0], marker='s', color='C1', label='2',
                   markerfacecolor='w', markersize=14, linestyle='None', markeredgewidth=2),
                   Line2D([0], [0], marker='D', color='C2', label='3',
                   markerfacecolor='w', markersize=14, linestyle='None', markeredgewidth=2),
                   Line2D([0], [0], marker='p', color='C3', label='4',
                   markerfacecolor='w', markersize=14, linestyle='None', markeredgewidth=2),
                   Line2D([0], [0], marker='P', color='C4', label='5',
                   markerfacecolor='w', markersize=14, linestyle='None', markeredgewidth=2),
                   Line2D([0], [0], marker='4', color='C5', label='6',
                   markerfacecolor='w', markersize=14, linestyle='None', markeredgewidth=2)]


ax.legend(handles=legend_elements, bbox_to_anchor=(0.1, 1.08), loc='upper left', 
          borderaxespad=0., ncol=3, fontsize=14)



f = plt.figure(figsize=(10,10))
ax = f.add_subplot(111)

ax.set_aspect('equal')

# iteratively add hexagons
for i in range(weights.shape[0]):
    for j in range(weights.shape[1]):
        wy = yy[(i, j)] * np.sqrt(3) / 2
        hex = RegularPolygon((xx[(i, j)], wy), 
                             numVertices=6, 
                             radius=.95 / np.sqrt(3),
                             facecolor=cm.Blues(umatrix[i, j]), 
                             alpha=.4, 
                             edgecolor='gray')
        ax.add_patch(hex)
markers = ['o', 's', 'D', 'p','P','4']
colors = ['C0', 'C1', 'C2','C3','C4','C5']

for cnt, x in enumerate(data):
    # getting the winner
    w = som.winner(x)
    # place a marker on the winning position for the sample xx
    wx, wy = som.convert_map_to_euclidean(w) 
    wy = wy * np.sqrt(3) / 2
    plt.plot(wx, wy, 
             markers[t[cnt]-1], 
             markerfacecolor='None',
             markeredgecolor=colors[t[cnt]-1], 
             markersize=12, 
             markeredgewidth=2)

xrange = np.arange(weights.shape[0])
yrange = np.arange(weights.shape[1])
plt.xticks(xrange-.5, xrange)
plt.yticks(yrange * np.sqrt(3) / 2, yrange)

divider = make_axes_locatable(plt.gca())
ax_cb = divider.new_horizontal(size="5%", pad=0.05)    
cb1 = colorbar.ColorbarBase(ax_cb, cmap=cm.Blues, 
                            orientation='vertical', alpha=.4)
cb1.ax.get_yaxis().labelpad = 16
cb1.ax.set_ylabel('distance from neurons in the neighbourhood',
                  rotation=270, fontsize=16)
plt.gcf().add_axes(ax_cb)

legend_elements = [Line2D([0], [0], marker='o', color='C0', label='1',
                   markerfacecolor='w', markersize=14, linestyle='None', markeredgewidth=2),
                   Line2D([0], [0], marker='s', color='C1', label='2',
                   markerfacecolor='w', markersize=14, linestyle='None', markeredgewidth=2),
                   Line2D([0], [0], marker='D', color='C2', label='3',
                   markerfacecolor='w', markersize=14, linestyle='None', markeredgewidth=2),
                   Line2D([0], [0], marker='p', color='C3', label='4',
                   markerfacecolor='w', markersize=14, linestyle='None', markeredgewidth=2),
                   Line2D([0], [0], marker='P', color='C4', label='5',
                   markerfacecolor='w', markersize=14, linestyle='None', markeredgewidth=2),
                   Line2D([0], [0], marker='4', color='C5', label='6',
                   markerfacecolor='w', markersize=14, linestyle='None', markeredgewidth=2)]


ax.legend(handles=legend_elements, bbox_to_anchor=(0.1, 1.08), loc='upper left', 
          borderaxespad=0., ncol=3, fontsize=14)

plt.savefig('som.png')
plt.show()
