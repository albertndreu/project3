import sys
import pandas as pd
import math
from sklearn import linear_model
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split


def ploti(true, predicted):

    # plot scatter plot
    plt.scatter(true, predicted)

    # add diagonal line
    diagonal = np.linspace(min(true), max(true))
    plt.plot(diagonal, diagonal, '--')

    plt.xlabel('True Values')
    plt.ylabel('Predicted Values')

    plt.title('Scatter plot')

    plt.show()

df = pd.read_csv(sys.argv[1], sep="\t", skiprows = 1)

X = df.iloc[:, 0:len(df.columns)-1]
Y = df.iloc[:, len(df.columns)-1]

X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=.2)

regr = linear_model.LinearRegression()
regr.fit(X_train, y_train)


T = X_test.values.tolist()
F = y_test.values.tolist()

errorT = 0
errorN = 0
count = 0
f = open("resultsMLR.txt", "w")
true = []
predicted = []
for row in T:
    
    predict = regr.predict([row])
    s="Predicted value: " + str(predict) + " Real value: " + str(F[count]) + "\n"
    f.write(s)
    predicted.append(predict)
    true.append(F[count])
    
    errorT = errorT + abs(predict-F[count])
    errorN = errorN + F[count]
    count = count +1

error = 100*errorT/errorN


s = "Error-rate MLR: " + str(error)
f.write(s)
f.close()

ploti(true, predicted)


