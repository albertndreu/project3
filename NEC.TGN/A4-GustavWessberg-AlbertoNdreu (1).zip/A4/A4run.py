import random
import networkx as nx
from collections import defaultdict
import matplotlib.pyplot as plt
import sys

class Net:
    def __init__(self):
        self.vertices = []
        self.edges = defaultdict(list)
        self.inverted_edges = defaultdict(list)

    def nr_edges(self):
        number_of_edges = 0
        for i in range(len(self.vertices)):
            if i in self.edges:
                number_of_edges += len(self.edges[i])
        return number_of_edges
    
    def add_inverted_edges(self):
        for e in self.edges.items():
            for v in self.edges[e[0]]:
                self.inverted_edges[v].append(e[0])

class Chromosome:
    def __init__(self, number_genes, genes):
        if genes == []:
            self.number_genes = number_genes
            self.fitness_score = 0.0
            self.get_random()
        else:
            self.number_genes = number_genes
            self.genes = genes
            self.fitness_score = 0.0

    def get_random(self):
        self.genes = []
        for i in range(self.number_genes):
            random1 = random.randint(0, 1)
            self.genes.append(random1)
        


def calc_modularity(net, chromosome):
    modularity = 1.0 / (2.0 * net.nr_edges())
    a = 0.0
    for i in range(1,len(net.vertices)+1):
        for j in range(1,len(net.vertices)+1):
            if (i in net.edges and j in net.edges[i]) or (i in net.inverted_edges and j in net.inverted_edges[i]):
                hasConnection = 1
            else:
                hasConnection = 0

            ki = len(net.edges[i]) + len(net.inverted_edges[i]) #Calculating the degrees
            kj = len(net.edges[j]) + len(net.inverted_edges[j])

            temp = (hasConnection - ((ki * kj) / (2.0 * net.nr_edges()))) #hasconnection - degrees/2*L
            if chromosome.genes[i-1] == chromosome.genes[j-1]: #Belongs to the same cluster
                a += temp
            else:
                pass            
    modularity *= a
    return modularity


def create_net(file):
    net = Net()
    reading_vertices = True
    with open(file, "r") as f:
        for line in f:
            line_splitted = line.strip().split()
            if "Edges" in line:
                reading_vertices = False
            if reading_vertices and "Vertices" not in line:
                net.vertices.append(int(line_splitted[0]))
            if not reading_vertices and "Edges" not in line:
                net.edges[int(line_splitted[0])].append(int(line_splitted[1]))
    net.add_inverted_edges()
    return net

def plot_net(net, best_chromo, f):
    G = nx.Graph()
    colorsm = []
    ones = []
    zeros = []
    index = 0
    for gene in best_chromo.genes:
        
        if gene == 1:
            colorsm.append("b")
            ones.append(index+1)
        else:
            colorsm.append("y")
            zeros.append(index+1)
        index += 1
            
    for node in net.vertices:
        G.add_node(node)
        
        
    for node in net.vertices:
        for edge in net.edges[node]:
            G.add_edge(node,edge)

    s = "Modularity real: " + str(round(nx.algorithms.community.modularity(G, [zeros, ones]),3))
    f.write(s)
    f.close()
    plt.figure()
    pos = nx.spring_layout(G)
    nx.draw_networkx_nodes(G, pos, node_color=colorsm)
    nx.draw_networkx_labels(G, pos)
    nx.draw_networkx_edges(G, pos, edge_color='r', arrows = True)
    plt.show()

def Selection(selection, population):
    selected_chromosomes = []
    if selection == "Rank":
        allranks = []
        RankScore = len(population)
        for chromo in population:
            allranks.append(RankScore)
            RankScore = RankScore - 1

        totfitness = 0
        for rank in allranks:
            totfitness + rank

        for k in range(10):
            
            random1 = random.random() * totfitness
            for i in range(len(population)):
                
                if random1 <= 0 and population[i] not in selected_chromosomes: 
                    selected_chromosomes.append(population[i])
                    
                    break

    elif selection == "Roulette":
        totfitness = 0
        for chromo in population:
            if(chromo.fitness_score > 0):
                totfitness = totfitness + chromo.fitness_score
        
        percentages = []
        for chromo in population:
            if(chromo.fitness_score > 0):
                percentages.append(chromo.fitness_score/totfitness)
            else:
                percentages.append(0)
            

        for k in range(10):
            random1 = random.random()
            for i in range(len(percentages)):
                random1 = random1 - percentages[i]
                
                if random1 <= 0 and population[i] not in selected_chromosomes:
                    selected_chromosomes.append(population[i])
                    break

    elif selection == "Tournament":
          for k in range(10):
            players = []
            
            for i in range(10):    
                r = random.randint(0,len(population)-1)
                if population[r] not in players and population[r] not in selected_chromosomes:
                    players.append(population[r])
            
            players.sort(key=lambda x:x.fitness_score, reverse=True)
            selected_chromosomes.append(players[0])
    else:
            print("Parameter Error")
                
    return selected_chromosomes

    

def Crossover(crossover, selected_chromosomes, populationnr):
    
    new_population = []

    for i in range(int(populationnr/2)):
        first = random.randint(0, 9)
        second = random.randint(0, 9)
        while(first == second):
            second = random.randint(0, 9)
             
        firstchromo = selected_chromosomes[first]
        secondchromo = selected_chromosomes[second]
        
        if crossover == "One_point":
            rand = random.randint(0,firstchromo.number_genes-1)

            firstkidgenes = firstchromo.genes[:rand] + secondchromo.genes[rand:]
            secondkidgenes = secondchromo.genes[rand:] + firstchromo.genes[:rand]

            firstkid = Chromosome(firstchromo.number_genes, firstkidgenes)
            secondkid = Chromosome(firstchromo.number_genes, secondkidgenes)

            new_population.append(firstkid)
            new_population.append(secondkid)

        elif crossover == "Uniform":
            firstkidgenes = firstchromo.genes
            secondkidgenes = secondchromo.genes
            for i in range(firstchromo.number_genes-1):
                r = random.random()
                if r > 0.5:
                    if firstkidgenes[i] != secondkidgenes[i]:
                        
                        temp = firstkidgenes[i]
                        firstkidgenes[i] = secondkidgenes[i]
                        secondkidgenes[i] = temp

                        
                        
            firstkid = Chromosome(firstchromo.number_genes, firstkidgenes)
            secondkid = Chromosome(firstchromo.number_genes, secondkidgenes)

            new_population.append(firstkid)
            new_population.append(secondkid)

        elif crossover == "Double_point":
            rand1 = random.randint(0,firstchromo.number_genes-1)
            rand2 = random.randint(0,firstchromo.number_genes-1)
            while rand1 == rand2:
                rand2 = random.randint(0,firstchromo.number_genes-1)
            if rand1 > rand2:
                temp = rand2
                rand2 = rand1
                rand1 = temp

            firstkidgenes = firstchromo.genes[:rand1] + secondchromo.genes[rand1:rand2] + firstchromo.genes[rand2:]
            secondkidgenes = secondchromo.genes[:rand1] + firstchromo.genes[rand1:rand2] + secondchromo.genes[rand2:]

            firstkid = Chromosome(firstchromo.number_genes, firstkidgenes)
            secondkid = Chromosome(firstchromo.number_genes, secondkidgenes)

            new_population.append(firstkid)
            new_population.append(secondkid)

        else:
            print("Parameter Error")

        
            
    return new_population


def Mutation(mutation, population):
    mutated_population = []
    if mutation == "All":
        flips = 0
        
        rand = random.Random()
        
        for chromo in population:
            
            for j in range(len(chromo.genes)):
                if rand.random() < 0.01:
                    flips = flips + 1
                    if chromo.genes[j] == 1:
                        chromo.genes[j] = 0
                    else:
                        chromo.genes[j] = 1
                    
            mutated_population.append(chromo)
        print("Flips: ", flips)

    elif(mutation == "One"):
        
        for chromo in population:
            index = random.randint(0,chromo.number_genes-1)
            if chromo.genes[index] == 1:
                chromo.genes[index] = 0
            else:
                chromo.genes[index] = 1
            
            mutated_population.append(chromo)   
            
        

    else:
        print("Parameter Error")
    return mutated_population
    
def sort(population):
    return sorted(population, key=lambda x: x.fitness_score, reverse=True)

def give_fitness(net, chromo):
    modularity = calc_modularity(net, chromo)
    chromo.fitness_score = modularity
    return chromo
    
def create_population(net, nr):
    population = []
    for i in range(nr):
        chromo = Chromosome(len(net.vertices), [])
        chromo = give_fitness(net, chromo)
        population.append(chromo)

    return sort(population)
    
        


def GA(net, selection, crossover, mutation, generations, populationnr):
    population = create_population(net, populationnr)
    best_chromo = population[0]

    for i in range(generations):
        print("Iteration: ", i)
        
        
        selected = Selection(selection, population)
        crossed = Crossover(crossover, selected, populationnr)
        
        mutated = Mutation(mutation, crossed)
        

        for chromo in mutated:
            chromo = give_fitness(net, chromo)
        
        population  = sort(mutated)
     

        #Elitism part
        if best_chromo.fitness_score < population[0].fitness_score:
            best_chromo = population[0]
        else:
            population.insert(0,best_chromo)
            population.pop()

        print(best_chromo.fitness_score)

    return best_chromo  

def create_clu(chromo):
    lines = []
    lines.append("*Vertices {}".format(chromo.number_genes))

    for i in range(chromo.number_genes):
        lines.append(str(chromo.genes[i]))

    file = "cluresults.clu"
    f = open(file, 'w')
    f.write("\n".join(lines))  

def parse_parameters(file):
    f = open(file, "r")
    params = []
    for i in range(3):
        params.append(f.readline().strip())
    for i in range(2):
        params.append(int(f.readline().strip()))
    return params
    
  

p = parse_parameters(sys.argv[2])

net = create_net(sys.argv[1])
best_chromo = GA(net, p[0], p[1], p[2], p[3], p[4])
print(best_chromo.fitness_score)
create_clu(best_chromo)

f = open("results.txt","w")
s="Results for GA with \n selection: " + p[0] +"\n crossover: " + p[1] + "\n Mutation: " + p[2] + "\n With "+ str(p[3])+ " generations and a population of" + str(p[4])  
f.write(s)
s = "\n Partition: " + str(best_chromo.genes)
f.write(s)
s = "\n Modularity calculated: " + str(round(best_chromo.fitness_score, 3)) + "\n"
f.write(s)
plot_net(net, best_chromo, f)


