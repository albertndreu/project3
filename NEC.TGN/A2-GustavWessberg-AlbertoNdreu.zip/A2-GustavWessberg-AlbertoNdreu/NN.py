import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OrdinalEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import accuracy_score
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LinearRegression
import sys
from sklearn.neural_network import MLPClassifier
import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import simps
from sklearn.decomposition import PCA
from sklearn.metrics import confusion_matrix
import itertools



def CleanBankData():

    df = pd.read_csv(sys.argv[1], sep=";")

    x1 = df.iloc[:,0:1]


    x2 = df.iloc[:,1:10] #Cat

    x3 = df.iloc[:,10:14]


    x4 = df.iloc[:,14:15] #Cat


    x5 = df.iloc[:,15:20]

    Y = df.iloc[:,20:21]

    oe = OrdinalEncoder()
    oe.fit(Y)
    Y_enc = oe.transform(Y)
    Y = pd.DataFrame(Y_enc)
    Y.rename(columns = {0:20}, inplace = True)
    print(Y)


    oe = OrdinalEncoder()
    oe.fit(x2)
    x2_enc = oe.transform(x2)

    oe2 = OrdinalEncoder()
    oe2.fit(x4)
    x4_enc = oe2.transform(x4)



    x2_enc_df = pd.DataFrame(x2_enc)

    x4_enc_df = pd.DataFrame(x4_enc)
    x4_enc_df.rename(columns = {0:'poutcome'}, inplace = True)


    x = x1.join(x2_enc_df)
    x = x.join(x3)

    x = x.join(x4_enc_df)
    x = x.join(x5)

    print(x)

    sclr = MinMaxScaler()
    new_df = sclr.fit_transform(x)

    realX = pd.DataFrame(new_df)

    print(realX)
    print(Y)

    return realX, Y


def CleanNumericalData():
    df = pd.read_csv(sys.argv[1], sep="\t", names=["x","y","z"])
    sclr = MinMaxScaler()
    new_df = sclr.fit_transform(df)
    df = pd.DataFrame(new_df)
    X = df.iloc[:, 0:len(df.columns)-1]
    Y = df.iloc[:, len(df.columns)-1]    
    return X,Y

def CleanVolleyball():
    df = pd.read_csv(sys.argv[1], sep=",")
    x = df.iloc[:,3:7]
    Y = df.iloc[:,7:8]
    sclr = MinMaxScaler()
    new_df = sclr.fit_transform(x)
    Y = Y['position_number'].values.tolist()
    for i in range(len(Y)):
        if Y[i] == 2 or Y[i] == 3 or Y[i] == 4:
            Y[i] = 1.0
        else:
            Y[i] = 0.0
    X = pd.DataFrame(new_df)
    Y = pd.DataFrame(Y)

    return X,Y

counter = 0
bestscore = 0.0
bestepochs = 0
bestlayer = 1
bestfunction = ""
bestlr = 0.0 
bestmomentum = 0.0
if sys.argv[1] == "bank-additional-full.csv" or sys.argv[1] == "bank-additional.csv":
    X,Y = CleanBankData()
elif(sys.argv[1] == "vb.csv"):
    X,Y = CleanVolleyball()
else:
    X,Y = CleanNumericalData()
f = open("resultsNN.txt", "w")
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=.2)
for epochs in [10]:
    for layer in [(50)]: #(50,), (100,), (200,),(100,50,), (100,100,100,)
        for function in ['logistic']: #'logistic', 'tanh', 'relu'
            for lr in [0.1]: #
                for momentum in [0.3]: #0.1, 0.3, 0.6, 0.9
                    print("Running iteration: ", counter)
                    counter = counter +1
                    nn = MLPClassifier(hidden_layer_sizes=layer,activation=function,learning_rate_init=lr, momentum=momentum, n_iter_no_change=epochs)
                    nn.fit(X_train,y_train)

                    scores = cross_val_score(nn,X,Y, cv=5, )
                    s1 = "Result of a network with layer: " + str(layer) +" epochs: "+str(epochs)+ " function: " + function + " Learning rate: " + str(lr) + " Momentum:"+ str(momentum)+ "\n"
                    s2 = str(scores)+ "\n"
                    f.write(s1)
                    f.write(s2)
                    f.write("\n")
                    
                    if scores.mean() > bestscore:
                        bestscore = scores.mean()
                        bestepochs = epochs
                        bestlayer = layer
                        bestfunction = function
                        bestlr = lr
                        bestmomentum = momentum

nn2= MLPClassifier(hidden_layer_sizes=bestlayer,activation=bestfunction,learning_rate_init=bestlr, momentum=bestmomentum, n_iter_no_change=bestepochs)
nn2.fit(X_train,y_train)

score = nn2.score(X_test, y_test)
error = 1-score
sc = "Best score: " + str(score) + "\n"
f.write(sc)
se = "With error: " + str(error) + "\n"
f.write(se)
sp = "Parameters: layer: " + str(bestlayer) +" epochs: "+str(bestepochs)+ " function: " + bestfunction + " Learning rate: " + str(bestlr) + " Momentum:"+ str(bestmomentum)+ "\n" 
f.write(sp)
predictions = nn2.predict(X_test)
predictionsprob = nn2.predict_proba(X_test)

pred = predictions

yt = y_test.values.tolist()

if sys.argv[1] == "bank-additional-full.csv" or sys.argv[1] == "bank-additional.csv" or sys.argv[1] == "vb.csv":
    yt = list(itertools.chain.from_iterable(yt))

falsepos = 0
falseneg = 0
truepos = 0
trueneg = 0
TPR = []
FPR = []

for thresh in [ 1.0, 0.9,0.8,0.7,0.6,0.5,0.4,0.3,0.2,0.1,0.0]:
    falsepos = 0
    falseneg = 0
    truepos = 0
    trueneg = 0
    for i in range(len(predictionsprob)):
        if predictionsprob[i][1]<thresh:
            predictedClass =0.0
        else:
            predictedClass = 1.0
    
        if predictedClass ==  yt[i]:
            if predictedClass == 1:
                truepos += 1
            else:
                trueneg += 1
        else:
            if predictedClass == 1:
                falsepos += 1
            else:
                falseneg += 1
    if(truepos+falseneg == 0):
        TPR.append(0.0)
    else:
        TPR.append(truepos/(truepos+falseneg))
    if(falsepos + trueneg == 0):
        FPR.append(0.0)
    else:
        FPR.append(falsepos/(falsepos + trueneg))


area = simps(TPR,FPR)
s = "AUC: " + str(area) + "\n"
f.write(s)
s = "Confusion matrix:\n" + str(confusion_matrix(y_test, pred))
f.write(s)
print(TPR)
print(FPR)

f2 = open("BestResultsNN.txt", "w")
f2.write(sc)
f2.write(se)
f2.write(sp)
s = "AUC: " + str(area) + "\n"
f2.write(s)
s = "Confusion matrix:\n" + str(confusion_matrix(y_test, pred))
f2.write(s)

s= "\nWeights:\n" + str(nn2.coefs_)
f2.write(s)

s= "\nBiases:\n" + str(nn2.intercepts_)
f2.write(s)
pca = PCA(n_components=2)
a = pca.fit_transform(X)
j = pd.DataFrame(a)
j.columns = ["x","y"]

pca = PCA(n_components=2)
b = pca.fit_transform(X_test)
k = pd.DataFrame(b)
k.columns = ["x","y"]

plt.figure()
plt.title("ROC-curve")
plt.plot(FPR,TPR)
plt.xlabel("FPR")
plt.ylabel("TPR")

plt.figure()
plt.title("PCA correct")
plt.scatter(j.x, j.y, s=20, c=Y, cmap='viridis')

plt.figure()
plt.title("PCA predictions best")
plt.scatter(k.x, k.y, s=20, c=predictions, cmap='viridis')

plt.show()
f.close()
f2.close()



