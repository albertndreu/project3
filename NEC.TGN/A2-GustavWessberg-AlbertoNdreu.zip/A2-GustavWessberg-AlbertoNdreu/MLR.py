import sys
import pandas as pd
import math
from sklearn import linear_model
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OrdinalEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.svm import SVC
import matplotlib.pyplot as plt
from scipy.integrate import simps
from sklearn.decomposition import PCA
import itertools

def CleaningBankData():
    
    df = pd.read_csv(sys.argv[1], sep=";")
    df.head()


    x1 = df.iloc[:,0:1]


    x2 = df.iloc[:,1:10] #Cat

    x3 = df.iloc[:,10:14]


    x4 = df.iloc[:,14:15] #Cat


    x5 = df.iloc[:,15:20]

    Y = df.iloc[:,20:21]

    oe = OrdinalEncoder()
    oe.fit(Y)
    Y_enc = oe.transform(Y)
    
    Y = pd.DataFrame(Y_enc)

    Y = Y.iloc[:,0]
   
    


    oe = OrdinalEncoder()
    oe.fit(x2)
    x2_enc = oe.transform(x2)

    oe2 = OrdinalEncoder()
    oe2.fit(x4)
    x4_enc = oe2.transform(x4)



    x2_enc_df = pd.DataFrame(x2_enc)

    x4_enc_df = pd.DataFrame(x4_enc)
    x4_enc_df.rename(columns = {0:'poutcome'}, inplace = True)


    x = x1.join(x2_enc_df)
    x = x.join(x3)

    x = x.join(x4_enc_df)
    x = x.join(x5)


    sclr = MinMaxScaler()
    new_df = sclr.fit_transform(x)

    X = pd.DataFrame(new_df)
    

    #print(realX)
    return X,Y



####

def CleanNumericalData():
    df = pd.read_csv(sys.argv[1], sep="\t", names=["x","y","z"])
    sclr = MinMaxScaler()
    new_df = sclr.fit_transform(df)
    df = pd.DataFrame(new_df)
    X = df.iloc[:, 0:len(df.columns)-1]
    Y = df.iloc[:, len(df.columns)-1]

    
    return X,Y

def CleanVolleyball():
    df = pd.read_csv(sys.argv[1], sep=",")
    x = df.iloc[:,3:7]
    Y = df.iloc[:,7:8]
    sclr = MinMaxScaler()
    new_df = sclr.fit_transform(x)
    Y = Y['position_number'].values.tolist()
    for i in range(len(Y)):
        if Y[i] == 2 or Y[i] == 3 or Y[i] == 4:
            Y[i] = 1.0
        else:
            Y[i] = 0.0
    X = pd.DataFrame(new_df)
    Y = pd.DataFrame(Y)

    return X,Y

    
if sys.argv[1] == "bank-additional-full.csv" or sys.argv[1] == "bank-additional.csv":
    X,Y = CleaningBankData()
elif(sys.argv[1] == "vb.csv"):
    X,Y = CleanVolleyball()
else:
    X,Y = CleanNumericalData()

X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=.2)



regr = linear_model.LinearRegression()
regr.fit(X_train, y_train)

T = X_test
F = y_test

T = T.values.tolist()

F = F.values.tolist()
if sys.argv[1] == "vb.csv":
    F = list(itertools.chain.from_iterable(F))

errorT = 0
errorN = 0
count = 0
corrects =0
predictedClass =0
falsepos = 0
falseneg = 0
truepos = 0
trueneg = 0
best =1
predictlist = []

TPR = []
FPR = []
f = open("resultsMLR.txt", "w")

for thresh in [1.0,0.9,0.8,0.7,0.6,0.5,0.45,0.4,0.3,0.2,0.1,0.0]:
    errorT = 0
    errorN = 0
    count = 0
    corrects =0
    predictedClass =0
    falsepos = 0
    falseneg = 0
    truepos = 0
    trueneg = 0
    threshold = 0.5

    s = "--------------Threshold  " + str(thresh) + "--------\n"
    f.write(s)
    
    for row in T:
        predict = regr.predict([row])
        
        
        if predict<thresh:
            predictedClass =0
        else:
            predictedClass = 1

        if thresh == 0.5:
            predictlist.append(predictedClass)
        

        
        if predictedClass == F[count]:
            if predictedClass == 1:
                truepos += 1
            else:
                trueneg += 1
            corrects = corrects +1
        else:
            if predictedClass == 1:
                falsepos += 1
            else:
                falseneg += 1
        
            
        count = count +1

    error = (count-corrects)/count
    if(error < best):
        best = error
        threshold = thresh


    s = "Error-rate MLR: " + str(error) + "\n"
    f.write(s)

    s = "Threshold: " + str(thresh) + "\n"
    f.write(s)
    s = "True positives: " + str(truepos) + "\n"
    f.write(s)
    
    if(truepos+falseneg == 0):
        TPR.append(0.0)
    else:
        TPR.append(truepos/(truepos+falseneg))
    if(falsepos + trueneg == 0):
        FPR.append(0.0)
    else:
        FPR.append(falsepos/(falsepos + trueneg))


s = "-----------------Final results------------------------\n"
f.write(s)

print(TPR)
print(FPR)

# Approximate the area using Simpson's rule
area = simps(TPR,FPR)

s = "Best threshold: " + str(threshold) + "\n"
f.write(s)

s = "With error: " + str(best) + "\n"
f.write(s)

s = "AUC: " + str(area) + "\n"
f.write(s)

s = "Confusion matrix:\n" + str(confusion_matrix(y_test, predictlist))
f.write(s)

f.close()
pca = PCA(n_components=2)
a = pca.fit_transform(X)

pca = PCA(n_components=2)
b = pca.fit_transform(T)

j = pd.DataFrame(a)
j.columns = ["x","y"]

k = pd.DataFrame(b)
k.columns = ["x","y"]


plt.figure()
plt.title("ROC-curve")
plt.plot(FPR,TPR)
plt.xlabel("FPR")
plt.ylabel("TPR")

plt.figure()
plt.title("PCA correct")
plt.scatter(j.x, j.y, s=20, c=Y, cmap='viridis')

plt.figure()
plt.title("PCA prediction fot t=0.5")
plt.scatter(k.x, k.y, s=20, c=predictlist, cmap='viridis')

plt.show()




