import sys
import pandas as pd
import math
from sklearn import linear_model
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OrdinalEncoder
from sklearn.preprocessing import MinMaxScaler

from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.svm import SVC
from sklearn import svm
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt
from sklearn.model_selection import cross_val_score

def CleanBankData():
    
    df = pd.read_csv(sys.argv[1], sep=";")
    df.head()


    x1 = df.iloc[:,0:1]


    x2 = df.iloc[:,1:10] #Cat

    x3 = df.iloc[:,10:14]


    x4 = df.iloc[:,14:15] #Cat


    x5 = df.iloc[:,15:20]

    Y = df.iloc[:,20:21]

    oe = OrdinalEncoder()
    oe.fit(Y)
    Y_enc = oe.transform(Y)
    
    Y = pd.DataFrame(Y_enc)

    Y = Y.iloc[:,0]
   
    


    oe = OrdinalEncoder()
    oe.fit(x2)
    x2_enc = oe.transform(x2)

    oe2 = OrdinalEncoder()
    oe2.fit(x4)
    x4_enc = oe2.transform(x4)



    x2_enc_df = pd.DataFrame(x2_enc)

    x4_enc_df = pd.DataFrame(x4_enc)
    x4_enc_df.rename(columns = {0:'poutcome'}, inplace = True)


    x = x1.join(x2_enc_df)
    x = x.join(x3)

    x = x.join(x4_enc_df)
    x = x.join(x5)


    sclr = MinMaxScaler()
    new_df = sclr.fit_transform(x)

    X = pd.DataFrame(new_df)
    

    #print(realX)
    return X,Y



####

def CleanNumericalData():
    df = pd.read_csv(sys.argv[1], sep="\t", names=["x","y","z"])
    sclr = MinMaxScaler()
    new_df = sclr.fit_transform(df)
    df = pd.DataFrame(new_df)
    X = df.iloc[:, 0:len(df.columns)-1]
    Y = df.iloc[:, len(df.columns)-1]

    
    return X,Y

def CleanVolleyball():
    df = pd.read_csv(sys.argv[1], sep=",")
    x = df.iloc[:,3:7]
    Y = df.iloc[:,7:8]
    sclr = MinMaxScaler()
    new_df = sclr.fit_transform(x)
    Y = Y['position_number'].values.tolist()
    for i in range(len(Y)):
        if Y[i] == 2 or Y[i] == 3 or Y[i] == 4:
            Y[i] = 1.0
        else:
            Y[i] = 0.0
    X = pd.DataFrame(new_df)
    Y = pd.DataFrame(Y)

    return X,Y


def runSVC(clf, X_train, y_train, f):
    scores = cross_val_score(clf, X_train, y_train, cv=5)
    f.write(i)
    f.write("\n")
        
        
    s = "Cross-validation scores: " + str(scores)
    print(s)
    f.write(s)
    f.write("\n")
        
    s = "Mean score:" +  str(scores.mean())
    f.write(s)
    f.write("\n")
        
 

    return scores

    
if sys.argv[1] == "bank-additional-full.csv" or sys.argv[1] == "bank-additional.csv":
    X,Y = CleanBankData()
elif(sys.argv[1] == "vb.csv"):
    X,Y = CleanVolleyball()
else:
    X,Y = CleanNumericalData()

X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=.2)

f = open("resultsSVC", "w")

clf = svm.SVC(C=50,kernel="rbf")    
clf.fit(X_train, y_train)


accuracy = clf.score(X_test, y_test)
s = "Accuracy:" + str(accuracy)
f.write(s)
f.write("\n")

y_pred = clf.predict(X_test)

pca = PCA(n_components=2)
b = pca.fit_transform(X)
k = pd.DataFrame(b)
k.columns = ["x","y"]

pca = PCA(n_components=2)
b = pca.fit_transform(X_test)
h = pd.DataFrame(b)
h.columns = ["x","y"]

plt.figure()
plt.title("PCA correct")
plt.scatter(k.x, k.y, s=20, c=Y, cmap='viridis')

plt.figure()
plt.title("PCA prediction")
plt.scatter(h.x, h.y, s=20, c=y_pred, cmap='viridis')

plt.show()
f.close()


